#include <iostream>
#include <fstream>
#include "correo.h"
#include "lectorcorreo.h"
#include "ldl.h"
using namespace std;

int main()
{
    LectorCorreo lector;
    lector.menu();
    return 0;
}
